import random
import string


class PaymentService:

    @staticmethod
    def generate_reference(prefix="DRV"):
        chars = ''.join(
            random.choices(
                string.ascii_uppercase + string.digits,
                k=10
            )
        )

        return f"{prefix}-{chars}"

    @staticmethod
    def process_payment(amount, method="Card"):

        # Prototype payment simulation

        return {
            "success": True,
            "reference": PaymentService.generate_reference(),
            "method": method,
            "amount": amount
        }