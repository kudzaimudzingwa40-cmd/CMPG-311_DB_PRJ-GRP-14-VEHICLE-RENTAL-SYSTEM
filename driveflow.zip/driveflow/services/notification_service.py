class NotificationService:

    @staticmethod
    def send_booking_confirmation(email, booking_id):

        print(f"""
        =========================
        BOOKING CONFIRMATION
        =========================
        Email: {email}
        Booking ID: {booking_id}
        =========================
        """)

        return True

    @staticmethod
    def send_payment_receipt(email, amount):

        print(f"""
        =========================
        PAYMENT RECEIPT
        =========================
        Email: {email}
        Amount Paid: R{amount}
        =========================
        """)

        return True