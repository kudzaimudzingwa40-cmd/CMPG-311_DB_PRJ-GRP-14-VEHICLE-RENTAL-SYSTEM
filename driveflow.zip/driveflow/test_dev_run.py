# run.py - Main application entry point
from logic import app
from db import init_db

if __name__ == "__main__":
    print("=" * 50)
    print("🚗 DRIVEFLOW - Backend Integration Server")
    print("=" * 50)
    
    # Initialize database for testing
    print("\n📦 Setting up development database...")
    init_db()
    
    print("\n✨ Starting Flask server...")
    print("📍 Access at: http://127.0.0.1:5000")
    print("🔐 Admin login: admin@driveflow.com / admin123")
    print("👤 Customer login: customer@test.com / customer123")
    print("\n⚠️  This is a DEVELOPMENT server - For integration testing only")
    print("=" * 50 + "\n")
    
    app.run(debug=True, host='127.0.0.1', port=5000)