# db.py - Backend Developer (Integrations) Development Database
import sqlite3
import os

DB_PATH = "driveflow.db"

def get_db():
    """Get database connection - Used by all your integration code"""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """
    DEVELOPMENT DATABASE SETUP
    This is ONLY for testing your payment/notification integrations.
    DBA will provide production schema separately.
    """
    print("🔧 Setting up development database for integration testing...")
    
    with get_db() as db:
        # MINIMAL tables needed for YOUR integration work
        # DO NOT optimize - DBA handles production schema
        
        # Users table - For notifications
        db.execute('''CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT DEFAULT 'customer',
            loyalty_points INTEGER DEFAULT 0
        )''')
        
        # Vehicles table - For booking references
        db.execute('''CREATE TABLE IF NOT EXISTS vehicles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            make TEXT NOT NULL,
            model TEXT NOT NULL,
            daily_rate REAL NOT NULL,
            status TEXT DEFAULT 'Available'
        )''')
        
        # Bookings table - Your payment integration needs this
        db.execute('''CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            pickup_date DATE NOT NULL,
            return_date DATE NOT NULL,
            total_amount REAL NOT NULL,
            discount_amount REAL DEFAULT 0,
            status TEXT DEFAULT 'Awaiting Payment'
        )''')
        
        # Payments table - YOUR payment service writes here
        db.execute('''CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            method TEXT,
            card_last4 TEXT,
            reference TEXT UNIQUE,
            status TEXT DEFAULT 'Paid'
        )''')
        
        # Penalties table - For payment integration
        db.execute('''CREATE TABLE IF NOT EXISTS penalties (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            status TEXT DEFAULT 'Unpaid'
        )''')
        
        # Loyalty transactions - For points system
        db.execute('''CREATE TABLE IF NOT EXISTS loyalty_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            points INTEGER NOT NULL,
            type TEXT,
            description TEXT,
            booking_id INTEGER
        )''')
        
        # Promo codes - For discount validation
        db.execute('''CREATE TABLE IF NOT EXISTS promo_codes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            discount_type TEXT,
            discount_value REAL NOT NULL,
            min_booking_amount REAL DEFAULT 0,
            max_uses INTEGER DEFAULT 100,
            uses INTEGER DEFAULT 0,
            active INTEGER DEFAULT 1
        )''')
        
        # Reviews table
        db.execute('''CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            rating INTEGER,
            comment TEXT
        )''')
        
        # Returns table
        db.execute('''CREATE TABLE IF NOT EXISTS returns (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            booking_id INTEGER UNIQUE NOT NULL,
            actual_return_date DATE NOT NULL,
            condition TEXT,
            days_late INTEGER DEFAULT 0
        )''')
        
        # Maintenance logs
        db.execute('''CREATE TABLE IF NOT EXISTS maintenance_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            vehicle_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            service_date DATE NOT NULL
        )''')
        
        # Audit logs - YOUR audit() function writes here
        db.execute('''CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            action TEXT NOT NULL,
            entity TEXT,
            entity_id INTEGER,
            details TEXT,
            ip_address TEXT
        )''')
        
        # Waitlist
        db.execute('''CREATE TABLE IF NOT EXISTS waitlist (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            vehicle_id INTEGER NOT NULL,
            requested_pickup DATE NOT NULL,
            requested_return DATE NOT NULL
        )''')
        
        db.commit()
        
        # Insert test data for YOUR integration testing
        cursor = db.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            from werkzeug.security import generate_password_hash
            
            print("📝 Inserting test data for integration testing...")
            
            # Test users
            db.execute("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                ("Admin User", "admin@driveflow.com", generate_password_hash("admin123"), "admin"))
            db.execute("INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)",
                ("Test Customer", "customer@test.com", generate_password_hash("customer123"), "customer"))
            
            # Test vehicles
            vehicles = [
                ("Toyota", "Corolla", 450.00, "Available"),
                ("Honda", "Civic", 500.00, "Available"),
                ("Toyota", "RAV4", 750.00, "Available"),
            ]
            for v in vehicles:
                db.execute("INSERT INTO vehicles (make, model, daily_rate, status) VALUES (?,?,?,?)", v)
            
            # Test booking for payment integration
            db.execute("""INSERT INTO bookings 
                (user_id, vehicle_id, pickup_date, return_date, total_amount, status) 
                VALUES (2, 1, '2026-06-01', '2026-06-05', 1800.00, 'Awaiting Payment')""")
            
            db.commit()
            print("✅ Test data inserted successfully!")
        
        print("✅ Development database ready for integration testing!")


def audit(user_id, action, entity, entity_id=None, details=None, ip_address=None):
    """Audit logging - YOUR integration logging function"""
    try:
        with get_db() as db:
            db.execute("""INSERT INTO audit_logs 
                (user_id, action, entity, entity_id, details, ip_address) 
                VALUES (?,?,?,?,?,?)""",
                (user_id, action, entity, entity_id, details, ip_address))
            db.commit()
    except Exception as e:
        print(f"⚠️ Audit log error (non-critical): {e}")