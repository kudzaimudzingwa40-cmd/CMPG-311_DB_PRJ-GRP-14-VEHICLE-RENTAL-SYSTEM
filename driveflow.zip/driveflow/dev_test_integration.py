# test_integration.py - Test your payment and notification integrations
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

def test_notification_service():
    """Test your notification integration"""
    from services.notification_service import NotificationService
    
    print("\n📧 TESTING NOTIFICATION SERVICE")
    print("-" * 40)
    
    result1 = NotificationService.send_booking_confirmation(
        email="test@example.com",
        booking_id="BK-12345"
    )
    print(f"✓ Booking confirmation: {'Sent' if result1 else 'Failed'}")
    
    result2 = NotificationService.send_payment_receipt(
        email="test@example.com",
        amount=1250.00
    )
    print(f"✓ Payment receipt: {'Sent' if result2 else 'Failed'}")
    
    return result1 and result2

def test_payment_service():
    """Test your payment integration"""
    from services.payment_service import PaymentService
    
    print("\n💰 TESTING PAYMENT SERVICE")
    print("-" * 40)
    
    # Test reference generation
    ref = PaymentService.generate_reference()
    print(f"✓ Reference generated: {ref}")
    
    # Test payment processing
    result = PaymentService.process_payment(amount=1250.00, method="Card")
    print(f"✓ Payment processed: {result['success']}")
    print(f"  - Reference: {result['reference']}")
    print(f"  - Amount: R{result['amount']}")
    print(f"  - Method: {result['method']}")
    
    return result['success']

def test_database():
    """Test database connectivity"""
    from db import get_db, init_db
    
    print("\n🗄️  TESTING DATABASE CONNECTION")
    print("-" * 40)
    
    # Reset database
    init_db()
    
    # Test connection and tables
    db = get_db()
    tables = db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
    print(f"✓ Connected to database")
    print(f"✓ Found {len(tables)} tables")
    
    # Test booking data for payment flow
    booking = db.execute("SELECT * FROM bookings WHERE status='Awaiting Payment'").fetchone()
    if booking:
        print(f"✓ Test booking ready for payment: #{booking['id']} - R{booking['total_amount']}")
    
    db.close()
    return True

def test_payment_flow():
    """Test complete payment integration flow"""
    from db import get_db
    from services.payment_service import PaymentService
    from services.notification_service import NotificationService
    
    print("\n🔄 TESTING COMPLETE PAYMENT FLOW")
    print("-" * 40)
    
    db = get_db()
    
    # 1. Get a test booking
    booking = db.execute("SELECT * FROM bookings WHERE status='Awaiting Payment' LIMIT 1").fetchone()
    if not booking:
        print("✗ No test booking found")
        return False
    
    print(f"1. Found booking #{booking['id']} - Amount: R{booking['total_amount']}")
    
    # 2. Process payment
    payment = PaymentService.process_payment(amount=booking['total_amount'], method="Card")
    if not payment['success']:
        print("✗ Payment processing failed")
        return False
    
    print(f"2. Payment processed - Reference: {payment['reference']}")
    
    # 3. Save payment record
    db.execute("""INSERT INTO payments (booking_id, amount, method, reference, status) 
                  VALUES (?,?,?,?,?)""",
               (booking['id'], payment['amount'], payment['method'], 
                payment['reference'], 'Paid'))
    db.commit()
    print(f"3. Payment saved to database")
    
    # 4. Send notifications
    user = db.execute("SELECT email FROM users WHERE id=?", (booking['user_id'],)).fetchone()
    if user:
        NotificationService.send_payment_receipt(email=user['email'], amount=payment['amount'])
        print(f"4. Receipt sent to {user['email']}")
    
    db.close()
    print("\n✅ Payment flow test COMPLETE!")
    return True

def run_all_tests():
    """Run all integration tests"""
    print("\n" + "=" * 50)
    print("🧪 BACKEND INTEGRATION TESTS")
    print("=" * 50)
    
    tests = [
        ("Notification Service", test_notification_service),
        ("Payment Service", test_payment_service),
        ("Database Connection", test_database),
        ("Complete Payment Flow", test_payment_flow),
    ]
    
    results = {}
    for name, test_func in tests:
        try:
            results[name] = test_func()
        except Exception as e:
            print(f"\n❌ {name} FAILED: {e}")
            results[name] = False
    
    print("\n" + "=" * 50)
    print("📊 TEST RESULTS")
    print("=" * 50)
    
    all_passed = True
    for name, passed in results.items():
        status = "✅" if passed else "❌"
        print(f"{status} {name}")
        if not passed:
            all_passed = False
    
    return all_passed

if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)