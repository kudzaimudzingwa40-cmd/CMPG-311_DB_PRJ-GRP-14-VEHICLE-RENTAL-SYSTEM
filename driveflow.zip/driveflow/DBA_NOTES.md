# Notes for Database Administrator (DBA)

## Current Development Schema Status

The backend integration code currently uses a **development database** (`db.py`) for testing purposes only. 

## Tables Used by Integration Code

The following tables are accessed by the payment/notification integration:

| Table | Integration Usage | Fields Required |
|-------|------------------|-----------------|
| `bookings` | Payment processing reads `total_amount`, `discount_amount` | id, user_id, total_amount, discount_amount, status |
| `payments` | Integration writes payment records | booking_id, amount, reference, status, method |
| `users` | Notifications need `email`, `name` | id, email, name |
| `penalties` | Payment integration for penalties | id, booking_id, amount, status |
| `audit_logs` | `audit()` function writes logs | user_id, action, entity, details |

## Queries Your Production Schema Must Support

```sql
-- Payment flow queries:
SELECT total_amount, discount_amount FROM bookings WHERE id = ?
UPDATE bookings SET status = 'Confirmed' WHERE id = ?
INSERT INTO payments (booking_id, amount, reference, status) VALUES (?,?,?,?)

-- Notification queries:
SELECT email, name FROM users WHERE id = ?

-- Penalty queries:
SELECT * FROM penalties WHERE booking_id = ? AND status = 'Unpaid'